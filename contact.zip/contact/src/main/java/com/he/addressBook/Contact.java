package com.he.addressBook;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Contact {
	@NotNull(message = " field is required")
	@Size(min = 1, max = 255, message = " Length must be in between 1 to 255")
	@Pattern(regexp = "^[a-zA-Z]+$", message = " Only alphabets and space are allowed")
	private String name;
	@Size(min = 0, max = 255, message = " Length must not exceed 255")
	private String organisation;
	private List<PhoneNumber> phoneNumbers;
	private List<Address> addresses;

	public Contact(String name, String organisation) throws Exception {
		this.name = name;
		this.organisation = organisation;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOrganisation() {
		return organisation;
	}

	public void setOrganisation(String organisation) {
		this.organisation = organisation;
	}

	public List<PhoneNumber> getPhoneNumbers() {
		return phoneNumbers;
	}

	public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public void addPhoneNumber(PhoneNumber phoneNumber) {
		if (this.phoneNumbers == null) {
			this.phoneNumbers = new ArrayList<>();
		}
		this.phoneNumbers.add(phoneNumber);

	}

	public void addAddress(Address address) {
		if (this.addresses == null) {
			this.addresses = new ArrayList<>();
		}
		this.addresses.add(address);
	}

}