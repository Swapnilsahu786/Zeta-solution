package com.he.addressBook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

public class AddressBook {
	HashMap<String, Contact> hm;

	public AddressBook() {
		hm = new HashMap<String, Contact>();
	}

	public void addContact(Contact contact) throws Exception {

		if (hm.containsKey(contact.getName())) {
			throw new Exception("Duplicate Contact Not allowed");
		} else {
			hm.put(contact.getName(), contact);
		}

	}

	public void deleteContact(String name) throws Exception {
		if (hm.containsKey(name)) {
			hm.remove(name);
		} else {
			throw new Exception("Contact not found");
		}
	}

	public void updateContact(String name, Contact contact) throws Exception {

		if (hm.containsKey(contact.getName())) {
			throw new Exception("Duplicate record found, update failed");
		} else {
			hm.putIfAbsent(name, contact);
		}
	}

	public List<Contact> searchByName(String name) {
		List<Contact> listContact = new ArrayList<Contact>();
		for (Entry<String, Contact> e : hm.entrySet()) {
			if (e.getKey().startsWith(name)) {
				
				listContact.add(e.getValue());
			}
		}

		return listContact;
	}

	public List<Contact> searchByOrganisation(String organisation) {
		List<Contact> listContact = new ArrayList<Contact>();
		for (Entry<String, Contact> e : hm.entrySet()) {
			if (e.getValue().getOrganisation().startsWith(organisation)) {
				listContact.add(e.getValue());
			}

		}
		return listContact;
	}

}