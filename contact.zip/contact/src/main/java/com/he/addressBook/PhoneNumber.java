package com.he.addressBook;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class PhoneNumber {
	@NotNull(message = "field is required")
	@Size(min = 1, max = 255, message = "Length must be in between 1 to 255")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Only alphabets and space are allowed")
	private String label;
	@Pattern(regexp = "(\\+61|0)[0-9]{10}", message = "Phone Number must of 10 digits")
	private String phoneNumber;

	public PhoneNumber(String label, String phoneNumber) throws Exception {
		this.label = label;
		this.phoneNumber = phoneNumber;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}
